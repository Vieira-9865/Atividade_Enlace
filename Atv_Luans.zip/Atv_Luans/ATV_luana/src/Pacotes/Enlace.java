package Pacotes;

public class Enlace {
	
	public int peso;
	
	
	public int getPeso() {
		return peso;
	}
	public void setPeso(int peso) {
		this.peso = peso;
	}
	

}
